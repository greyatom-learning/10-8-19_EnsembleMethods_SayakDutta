import pandas as pd
import numpy as np
import sklearn
from sklearn import metrics
import statsmodels.api as sm
from statsmodels.stats.outliers_influence import variance_inflation_factor

from time import time
from scipy.stats import randint as sp_randint
from sklearn.model_selection import GridSearchCV
from sklearn.model_selection import RandomizedSearchCV
from sklearn.datasets import load_digits

from sklearn.datasets import load_digits
from sklearn.ensemble import RandomForestRegressor

from sklearn.decomposition import PCA
from sklearn.model_selection import train_test_split
import pandas as pd

import matplotlib.pyplot as plt

from sklearn.preprocessing import scale

df = pd.read_csv('/Users/saydutta/Desktop/Projects/Kaggle House Prices/house-prices-advanced-regression-techniques/train.csv')

df.head()

df.select_dtypes(include=['int64','float64']).columns
df.select_dtypes(include=['object']).columns


dummy_variable_list=['MSZoning', 'Street', 'Alley', 'LotShape', 'LandContour', 'Utilities',
       'LotConfig', 'LandSlope', 'Neighborhood', 'Condition1', 'Condition2',
       'BldgType', 'HouseStyle', 'RoofStyle', 'RoofMatl', 'Exterior1st',
       'Exterior2nd', 'MasVnrType', 'ExterQual', 'ExterCond', 'Foundation',
       'BsmtQual', 'BsmtCond', 'BsmtExposure', 'BsmtFinType1', 'BsmtFinType2',
       'Heating', 'HeatingQC', 'CentralAir', 'Electrical', 'KitchenQual',
       'Functional', 'FireplaceQu', 'GarageType', 'GarageFinish', 'GarageQual',
       'GarageCond', 'PavedDrive', 'Fence', 'MiscFeature',
       'SaleType', 'SaleCondition']

# 'PoolQC','MiscFeature','Alley','Fence','FireplaceQu','LotFrontage'

df_1 = df[['MSSubClass', 'LotFrontage', 'LotArea', 'OverallQual',
       'OverallCond', 'YearBuilt', 'YearRemodAdd', 'MasVnrArea', 'BsmtFinSF1',
       'BsmtFinSF2', 'BsmtUnfSF', 'TotalBsmtSF', '1stFlrSF', '2ndFlrSF',
       'LowQualFinSF', 'GrLivArea', 'BsmtFullBath', 'BsmtHalfBath', 'FullBath',
       'HalfBath', 'BedroomAbvGr', 'KitchenAbvGr', 'TotRmsAbvGrd',
       'Fireplaces', 'GarageYrBlt', 'GarageCars', 'GarageArea', 'WoodDeckSF',
       'OpenPorchSF', 'EnclosedPorch', '3SsnPorch', 'ScreenPorch', 'PoolArea',
       'MiscVal', 'MoSold', 'YrSold', 'SalePrice']]

all_data_na = (df.isnull().sum() / len(df)) * 100
all_data_na = all_data_na.drop(all_data_na[all_data_na == 0].index).sort_values(ascending=False)[:30]
missing_data = pd.DataFrame({'Missing Ratio' :all_data_na})
missing_data

x=pd.DataFrame()
for variables in dummy_variable_list:
    print(variables)
    x=pd.get_dummies(df[variables],prefix=variables+'_')
    # print(x)
    df_1=pd.concat([df_1,x],axis=1)

df_1.dropna(inplace=True)

X_train2, X_test2, y_train2, y_test2 = train_test_split(df_1 , df_1.SalePrice, test_size=0.3)

lm2 = RandomForestRegressor(n_estimators=1000,n_jobs=1,oob_score=True)

model = lm2.fit(X_train2, y_train2)

model

predict_test=pd.DataFrame(model.predict(X_test2)).reset_index()
y_test2=pd.DataFrame(y_test2).reset_index()

mape_data_test = pd.concat([predict_test,y_test2],axis=1)

mape_data_test=mape_data_test.rename(columns={0:'Predicted_SP'})

mape_data_test['error']=(abs(mape_data_test.Predicted_SP-mape_data_test.SalePrice)/mape_data_test.SalePrice)*100

mape_data_test['error'].mean()
